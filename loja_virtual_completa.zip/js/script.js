function adicionarAoCarrinho(produto) {
    alert(produto + " foi adicionado ao carrinho!");
    window.location.href = "endereco.html";
}